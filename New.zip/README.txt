PURE SHINE CLEANING MANAGER

Upload ALL files in this folder to the root of your GitHub repository:
- index.html
- icon.png
- background.jpg
- all photo-*.jpg files

Then open the GitHub Pages URL.

Do not rename the files.
