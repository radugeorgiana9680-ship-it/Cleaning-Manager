PURE SHINE CLEANING MANAGER — FINAL V2

Upload these 5 files to the root of your GitHub Pages repository:
1. index.html
2. icon.png
3. welcome-bg.jpg
4. manifest.json
5. sw.js

Important:
- Do not rename the files.
- index.html uses icon.png and welcome-bg.jpg.
- Free time opens availability, not the timer.
- Clients can be edited or deleted.
- Schedule lets you edit a client's day/time/rate/frequency.
- Data is saved locally in the browser/device.

After committing, wait for GitHub Pages to redeploy, then refresh the site.
